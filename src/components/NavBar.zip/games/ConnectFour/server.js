// server.js — robust Connect Four WS server with matchmaking queue + keepalive
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const ConnectFourGame = require('./ConnectFourGame');

const app = express();
app.get('/health', (_req, res) => res.status(200).send('ok'));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const START_PORT = Number(process.env.PORT || 3001);
let currentPort = START_PORT;

/* -------------------- Helpers -------------------- */
function isOpen(ws) {
  try { return ws && ws.readyState === ws.OPEN; } catch { return false; }
}
function send(ws, obj) {
  if (!isOpen(ws)) return;
  try { ws.send(JSON.stringify(obj)); } catch {}
}
function safeClose(ws) {
  try { ws.terminate?.(); } catch {}
}

/* ---------------- Lobby & Rooms ------------------ */

// FIFO queue for public matchmaking
const waitingQueue = []; // array of ws

// roomId -> { game, players:[ws1, ws2], rematchVotes:Set<ws> }
const rooms = new Map();

function broadcast(roomId, obj) {
  const room = rooms.get(roomId);
  if (!room) return;
  for (const p of room.players) send(p, obj);
}

function broadcastState(roomId) {
  const room = rooms.get(roomId);
  if (!room) return;
  const g = room.game;
  broadcast(roomId, {
    type: 'gameUpdate',
    board: g.board,
    currentPlayer: g.currentPlayer,
    winner: g.winner,
    lastMove: g.lastMove ? { row: g.lastMove.row, col: g.lastMove.col } : null,
  });
}

function makeRoom(a, b) {
  if (!isOpen(a) || !isOpen(b)) return;
  const roomId = Math.random().toString(36).slice(2);
  const game = new ConnectFourGame(6, 7);

  rooms.set(roomId, { game, players: [a, b], rematchVotes: new Set() });

  a.__roomId = roomId; a.__role = 'Player 1';
  b.__roomId = roomId; b.__role = 'Player 2';

  game.addPlayer?.(a, a.__username || null);
  game.addPlayer?.(b, b.__username || null);

  send(a, { type: 'startGame', playerNumber: 1, currentPlayer: game.currentPlayer, username: a.__username || null });
  send(b, { type: 'startGame', playerNumber: 2, currentPlayer: game.currentPlayer, username: b.__username || null });

  broadcastState(roomId);
}

function tryMatch() {
  // Clean dead sockets at the front
  while (waitingQueue.length && !isOpen(waitingQueue[0])) waitingQueue.shift();

  while (waitingQueue.length >= 2) {
    const a = waitingQueue.shift();
    if (!isOpen(a)) continue;
    // Ensure next live partner
    while (waitingQueue.length && !isOpen(waitingQueue[0])) waitingQueue.shift();
    if (!waitingQueue.length) {
      // Put 'a' back if no partner
      waitingQueue.unshift(a);
      break;
    }
    const b = waitingQueue.shift();
    if (!isOpen(b)) {
      waitingQueue.unshift(a);
      break;
    }
    makeRoom(a, b);
  }
}

function leaveRoom(ws) {
  const roomId = ws.__roomId;
  ws.__roomId = null;
  ws.__role = null;

  // Remove from queue if there
  const idx = waitingQueue.indexOf(ws);
  if (idx !== -1) waitingQueue.splice(idx, 1);

  if (!roomId) return;
  const room = rooms.get(roomId);
  if (!room) return;

  const others = room.players.filter(p => p !== ws);
  rooms.delete(roomId);

  for (const p of others) {
    p.__roomId = null;
    p.__role = null;
    send(p, { type: 'opponentLeft' });
  }
}

/* ---------------- WebSocket Wiring ---------------- */
wss.on('connection', (ws) => {
  ws.__roomId = null;
  ws.__role = null;
  ws.__username = null;
  ws.isAlive = true;

  send(ws, { type: 'lobby', status: waitingQueue.length ? 'matching' : 'waiting' });

  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (buf) => {
    let data;
    try { data = JSON.parse(buf.toString()); } catch { return; }

    switch (data.type) {
      case 'joinGame': {
        ws.__username = data.username || null;

        // If client thinks it's in a room that no longer exists, clear flags
        if (ws.__roomId && !rooms.get(ws.__roomId)) {
          ws.__roomId = null;
          ws.__role = null;
        }
        if (ws.__roomId) return; // already in a valid room

        if (!waitingQueue.includes(ws)) waitingQueue.push(ws);
        send(ws, { type: 'lobby', status: 'queued' });
        tryMatch();
        break;
      }

      case 'makeMove': {
        if (typeof data.col !== 'number') return;
        const roomId = ws.__roomId;
        const room = rooms.get(roomId);
        if (!room) return;
        const g = room.game;
        if (g.gameOver) return;
        if (g.currentPlayer !== ws.__role) return;

        const ok = g.makeMove(data.col);
        if (ok) broadcastState(roomId);
        break;
      }

      case 'resetGame': {
        const roomId = ws.__roomId;
        const room = rooms.get(roomId);
        if (!room) return;
        room.game.reset();
        room.rematchVotes.clear();
        broadcastState(roomId);
        break;
      }

      case 'rematch': {
        const roomId = ws.__roomId;
        const room = rooms.get(roomId);
        if (!room) return;

        room.rematchVotes.add(ws);
        broadcast(roomId, { type: 'rematchStatus', votes: room.rematchVotes.size });

        if (room.rematchVotes.size === room.players.length) {
          room.game.reset();
          room.rematchVotes.clear();
          broadcast(roomId, { type: 'rematchStart' });
          broadcastState(roomId);
        }
        break;
      }

      case 'leaveGame': {
        leaveRoom(ws);
        break;
      }

      default:
        break;
    }
  });

  ws.on('close', () => {
    leaveRoom(ws);
  });
});

/* ---------------- Ping/Pong Keepalive ---------------- */
const PING_MS = 15000;
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) {
      // If dead, ensure it isn't lingering in queue or room
      leaveRoom(ws);
      safeClose(ws);
      continue;
    }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  }
}, PING_MS);

/* ---------------- Start Server (with auto-fallback) ---------------- */
function startServer(port) {
  server.listen(port, '0.0.0.0', () => {
    console.log(`WS server listening on ws://0.0.0.0:${port}`);
  });
}
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.warn(`Port ${currentPort} in use, trying ${currentPort + 1}…`);
    currentPort += 1;
    setTimeout(() => startServer(currentPort), 200);
  } else {
    console.error('Server error:', err);
    process.exit(1);
  }
});
startServer(currentPort);
