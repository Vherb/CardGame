/* eslint-disable no-console */
import React, { useEffect, useRef, useState, useCallback } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './GameBoard.css';
import NavBar from "./../../NavBar";

/* ========================= Constants ========================= */
const ROWS = 6;
const COLUMNS = 7;
const makeBoard = () => Array.from({ length: ROWS }, () => Array(COLUMNS).fill(null));

/* WebSocket endpoint (Render) */
const RENDER_WS = 'wss://con4-1.onrender.com/';
const getWsUrl = () => RENDER_WS;

/* ======= SC wallet helpers (same style as your Roll-of-Cards game) ======= */
const API = 'http://localhost:3002';
function authFetch(path, options = {}) {
  const token = localStorage.getItem('token') || '';
  return fetch(`${API}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });
}

/* Adjust current user's SC balance by delta (+/-) */
async function scAdjust(delta, memo = '') {
  const r = await authFetch('/sc/adjust', {
    method: 'POST',
    body: JSON.stringify({ delta: Number(delta), memo }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j?.message || 'SC adjust failed');
  return j; // { sc_balance: number, ...}
}
async function getBalance() {
  const r = await authFetch('/balance');
  const j = await r.json().catch(()=>({ sc_balance: 0 }));
  return Number(j.sc_balance) || 0;
}

/* ========================= Audio ========================= */
function useDropSound() {
  const ctxRef = useRef(null);
  const interactedRef = useRef(false);

  const prime = useCallback(() => {
    interactedRef.current = true;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!ctxRef.current) ctxRef.current = new AC();
    if (ctxRef.current.state === 'suspended') ctxRef.current.resume();
  }, []);

  const playDrop = useCallback(() => {
    if (!interactedRef.current || !ctxRef.current) return;
    const ctx = ctxRef.current;
    const now = ctx.currentTime;

    // noise thunk
    const noiseBuf = ctx.createBuffer(1, 2048, ctx.sampleRate);
    const ch = noiseBuf.getChannelData(0);
    for (let i = 0; i < ch.length; i++) ch[i] = (Math.random() * 2 - 1) * 0.35;

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuf;
    const nFilter = ctx.createBiquadFilter();
    nFilter.type = 'lowpass';
    nFilter.frequency.setValueAtTime(900, now);
    const nGain = ctx.createGain();
    nGain.gain.setValueAtTime(0.0, now);
    nGain.gain.linearRampToValueAtTime(0.06, now + 0.005);
    nGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);
    noise.connect(nFilter).connect(nGain).connect(ctx.destination);

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(190, now + 0.08);
    const oGain = ctx.createGain();
    oGain.gain.setValueAtTime(0.0, now);
    oGain.gain.linearRampToValueAtTime(0.05, now + 0.005);
    oGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
    osc.connect(oGain).connect(ctx.destination);

    noise.start(now); noise.stop(now + 0.1);
    osc.start(now);   osc.stop(now + 0.14);
  }, []);

  return { prime, playDrop };
}

function useAudioClip(src, { volume = 1 } = {}) {
  const audioRef = useRef(null);

  useEffect(() => {
    const a = new Audio(src);
    a.preload = 'auto';
    a.volume = volume;
    a.addEventListener('error', () => {});
    audioRef.current = a;
    return () => { try { a.pause(); } catch {} audioRef.current = null; };
  }, [src, volume]);

  const play = useCallback(() => {
    const a = audioRef.current;
    if (!a) return;
    try { a.currentTime = 0; a.play().catch(() => {}); } catch {}
  }, []);

  return { play };
}

/* ========================= Color helpers ========================= */
const PALETTE = [
  '#EF4444', // red
  '#3B82F6', // blue
  '#A855F7', // purple
  '#FFFFFF', // white
  '#22C55E', // green
  '#F97316', // orange
  '#000000', // black
  '#6B7280', // gray
];

function hexToRgb(hex) {
  const s = hex.replace('#', '');
  const v = s.length === 3 ? s.split('').map(c => c + c).join('') : s;
  const n = parseInt(v, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}
function darken(hex, amt = 0.25) {
  const { r, g, b } = hexToRgb(hex);
  const mix = (c) => Math.max(0, Math.floor(c * (1 - amt)));
  return `rgb(${mix(r)}, ${mix(g)}, ${mix(b)})`;
}
function tokenStyleFor(color) {
  const base = color || '#ef4444';
  const edge = darken(base, 0.25);
  const shadow = darken(base, 0.45);
  return {
    background: `radial-gradient(circle at 30% 30%, ${base} 0%, ${edge} 55%, ${shadow} 100%)`,
    boxShadow: `inset 0 .4rem 1rem rgba(0,0,0,.22), 0 3px 8px rgba(0,0,0,.25)`
  };
}
function contrastText(hex) {
  const { r, g, b } = hexToRgb(hex);
  const y = 0.2126*r + 0.7152*g + 0.0722*b;
  return y > 140 ? '#0b1220' : '#ffffff';
}

/* ========================= Avatars ========================= */
const AVATAR_SET = [
  { id: 'rocket',   label: 'Rocket',   glyph: '🚀' },
  { id: 'dragon',   label: 'Dragon',   glyph: '🐉' },
  { id: 'brain',    label: 'Brain',    glyph: '🧠' },
  { id: 'fox',      label: 'Fox',      glyph: '🦊' },
  { id: 'lion',     label: 'Lion',     glyph: '🦁' },
  { id: 'panda',    label: 'Panda',    glyph: '🐼' },
  { id: 'penguin',  label: 'Penguin',  glyph: '🐧' },
  { id: 'alien',    label: 'Alien',    glyph: '👾' },
];
const findAvatar = (id) => AVATAR_SET.find(a => a.id === id) || AVATAR_SET[0];

const Avatar = ({ id, size = 22 }) => {
  const a = findAvatar(id);
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        display: 'grid',
        placeItems: 'center',
        background: '#0f172a',
        color: '#fff',
        border: '2px solid rgba(255,255,255,.45)',
        boxShadow: '0 4px 10px rgba(0,0,0,.3)',
        fontSize: Math.round(size * 0.7),
        lineHeight: 1,
      }}
      aria-label={a.label}
      title={a.label}
    >
      {a.glyph}
    </div>
  );
};

/* ========================= Component ========================= */
export default function GameBoard({ embedded = false }) {
  // core game state
  const [board, setBoard] = useState(makeBoard());
  const [currentPlayer, setCurrentPlayer] = useState('Looking for another player...');
  const [winner, setWinner] = useState(null);
  const [isGameStarted, setIsGameStarted] = useState(false);
  const [playerRole, setPlayerRole] = useState(null); // 'Player 1' | 'Player 2'

  // scoreboard
  const [player1Wins, setPlayer1Wins] = useState(parseInt(localStorage.getItem('player1Wins') || '0', 10));
  const [player2Wins, setPlayer2Wins] = useState(parseInt(localStorage.getItem('player2Wins') || '0', 10));

  // ui & audio
  const [muted, setMuted] = useState(false);
  const [lastMove, setLastMove] = useState(null);
  const [turnToast, setTurnToast] = useState(null);
  const [, _setLobbyStatus] = useState('idle'); // for little banner logic

  // identity & cosmetics
  const [username, setUsername] = useState(() => (localStorage.getItem('username') || '').slice(0, 16));
  const [selectedColor, setSelectedColor] = useState(localStorage.getItem('cfColor') || '#EF4444');
  const [avatarId, setAvatarId] = useState(localStorage.getItem('cfAvatar') || 'rocket');

  const [colors, setColors] = useState({ 'Player 1': '#EF4444', 'Player 2': '#3B82F6' });
  const [myName, setMyName] = useState('You');
  const [oppName, setOppName] = useState('Opponent');
  const [myAvatarId, setMyAvatarId] = useState(avatarId);
  const [oppAvatarId, setOppAvatarId] = useState('alien'); // placeholder until paired

  // SC wallet
  const [scBalance, setScBalance] = useState(0);

  // stake typed by user
  const [stakeSC, setStakeSC] = useState(() => {
    const v = Number(localStorage.getItem('cfStake') || '1');
    return Number.isFinite(v) && v > 0 ? v : 1;
  });

  // avatar modal
  const [showAvatarModal, setShowAvatarModal] = useState(false);

  // rematch
  const [rematchVotes, setRematchVotes] = useState(0);
  const [hasVotedRematch, setHasVotedRematch] = useState(false);

  // matchmaking modal
  const [showMatch, setShowMatch] = useState(false);
  const [pairedInfo, setPairedInfo] = useState(null);  // { you, usernames, colors, avatars, stakes? }
  const [countdown, setCountdown] = useState(null);    // server ticks

  // sound timings
  const dropSound = useDropSound();
  const winSound = useAudioClip('/sounds/win.mp3', { volume: 0.9 });
  const loseSound = useAudioClip('/sounds/lose.mp3', { volume: 0.9 });
  const IMPACT_FRAC = 0.70;
  const FALL_ADVANCE_MS = 60;
  const WIN_SOUND_DELAY_MS = 220;

  // refs
  const wsRef = useRef(null);
  const currentPlayerRef = useRef(currentPlayer);
  const playerRoleRef = useRef(playerRole);
  const mutedRef = useRef(muted);
  const prevBoardRef = useRef(makeBoard());
  const connectWSRef = useRef(() => {});
  const gameActiveRef = useRef(false);
  const playTimerRef = useRef(null);
  const winTimerRef = useRef(null);
  const didInitRef = useRef(false);
  const lobbyRef = useRef('idle');

  // escrow / settlement refs
  const lockedStakeRef = useRef(0);     // how much we locked for the current pending game
  const settledOnceRef = useRef(false); // ensure one-time settlement per game

  useEffect(() => { currentPlayerRef.current = currentPlayer; }, [currentPlayer]);
  useEffect(() => { playerRoleRef.current = playerRole; }, [playerRole]);
  useEffect(() => { mutedRef.current = muted; }, [muted]);

  // Load SC balance on mount and when token changes
  useEffect(() => {
    (async () => {
      try { setScBalance(await getBalance()); } catch {}
    })();
  }, []);

  // helpers
  const setLobbyStatus = useCallback((next, { force = false } = {}) => {
    const cur = lobbyRef.current;
    const isDowngrade = (cur === 'queued' || cur === 'matching') && (next === 'idle' || next === 'waiting');
    if (isDowngrade && !force) return;
    lobbyRef.current = next;
    _setLobbyStatus(next);
  }, [_setLobbyStatus]);

  const primeAudio = useCallback(() => { dropSound.prime(); }, [dropSound]);

  const cloneBoard = (b) => b.map(row => row.slice());
  const findNewMove = (prev, next) => {
    for (let r = ROWS - 1; r >= 0; r--) {
      for (let c = 0; c < COLUMNS; c++) {
        if (prev[r][c] == null && next[r][c] != null) return { row: r, col: c };
      }
    }
    return null;
  };

  /* Sound timing for drop impact */
  const scheduleImpactSound = useCallback(() => {
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) { if (!mutedRef.current) dropSound.playDrop(); return; }
    const prefersMobile = window.matchMedia && window.matchMedia('(max-width: 480px)').matches;
    const baseMs = prefersMobile ? 1100 : 900;
    const impactMs = Math.max(0, Math.floor(baseMs * IMPACT_FRAC) - FALL_ADVANCE_MS);
    if (playTimerRef.current) clearTimeout(playTimerRef.current);
    playTimerRef.current = setTimeout(() => {
      playTimerRef.current = null;
      if (!mutedRef.current) dropSound.playDrop();
    }, impactMs);
  }, [dropSound]);

  /* ========================= WebSocket ========================= */
  const cleanSocket = useCallback(() => {
    const ws = wsRef.current;
    if (ws) {
      try { ws.onopen = ws.onmessage = ws.onclose = ws.onerror = null; } catch {}
      try { if (ws.readyState === WebSocket.OPEN) ws.close(1000, 'cleanup'); } catch {}
    }
    wsRef.current = null;
  }, []);

  // Lock stake helper (escrow)
  const lockStake = useCallback(async (amt) => {
    const a = Math.max(0.01, Number(amt) || 0);
    if (lockedStakeRef.current > 0) return true; // already locked
    // quick balance check
    const bal = await getBalance().catch(() => 0);
    if (bal < a) {
      alert(`Insufficient SC. You have ${bal.toFixed(2)} SC, need ${a.toFixed(2)} SC.`);
      return false;
    }
    try {
      const j = await scAdjust(-a, 'Connect Four — lock stake');
      lockedStakeRef.current = a;
      setScBalance(Number(j.sc_balance) || 0);
      return true;
    } catch (e) {
      alert(e.message || 'Could not lock stake.');
      return false;
    }
  }, []);

  const refundStake = useCallback(async (reason = 'refund') => {
    const a = lockedStakeRef.current;
    if (a > 0) {
      try {
        const j = await scAdjust(+a, `Connect Four — ${reason}`);
        setScBalance(Number(j.sc_balance) || 0);
      } catch {}
      lockedStakeRef.current = 0;
    }
  }, []);

  const settleWin = useCallback(async (myStake, oppStake) => {
    // Winner gets: my locked stake back + opponent stake
    const credit = Number(myStake || 0) + Number(oppStake || 0);
    if (!credit || credit <= 0) return;
    try {
      const j = await scAdjust(+credit, 'Connect Four — win payout');
      setScBalance(Number(j.sc_balance) || 0);
    } catch (e) {
      // If payout fails, at least refund locked stake
      try {
        const j2 = await scAdjust(+Number(myStake || 0), 'Connect Four — payout fallback refund');
        setScBalance(Number(j2.sc_balance) || 0);
      } catch {}
    }
    lockedStakeRef.current = 0;
  }, []);

  const attachHandlers = useCallback((ws) => {
    ws.onopen = () => {
      setLobbyStatus('idle', { force: true });
      setCurrentPlayer('Looking for another player...');
    };

    ws.onerror = () => {};

    ws.onmessage = (e) => {
      const data = JSON.parse(e.data);

      if (data.type === 'queued') {
        setLobbyStatus('queued');
        return;
      }

      // Paired — both sides receive this, with per-client "you"
      if (data.type === 'paired') {
        setPairedInfo({
          you: data.you, // 1 or 2
          usernames: data.usernames || { 'Player 1':'Player 1', 'Player 2':'Player 2' },
          colors: data.colors || { 'Player 1':'#EF4444', 'Player 2':'#3B82F6' },
          avatars: data.avatars || { 'Player 1':'rocket', 'Player 2':'alien' },
          stakes: data.stakes || (
            data.you === 2
              ? { 'Player 1': '—', 'Player 2': Number(stakeSC) || 0 }
              : { 'Player 1': Number(stakeSC) || 0, 'Player 2': '—' }
          ),
          roomId: data.roomId || data.gameId || null,
        });
        setShowMatch(true);
        setCountdown(null);
        setLobbyStatus('matching');
        return;
      }

      // Countdown tick
      if (data.type === 'countdown' && typeof data.value === 'number') {
        setCountdown(data.value);
        return;
      }

      // Start game
      if (data.type === 'startGame') {
        setShowMatch(false);
        setCountdown(null);
        gameActiveRef.current = true;
        settledOnceRef.current = false;

        // ensure my stake is locked (in case we locked late)
        const myDesiredStake = Math.max(0.01, Number(stakeSC) || 0);
        (async () => {
          if (lockedStakeRef.current <= 0) {
            await lockStake(myDesiredStake);
          }
        })();

        setIsGameStarted(true);
        setWinner(null);

        const role = data.playerNumber === 1 ? 'Player 1' : 'Player 2';
        setPlayerRole(role);
        setCurrentPlayer(data.currentPlayer || 'Player 1');

        // Names
        if (data.usernames) {
          const n1 = (data.usernames['Player 1'] || 'Player 1').slice(0, 16);
          const n2 = (data.usernames['Player 2'] || 'Player 2').slice(0, 16);
          setMyName(role === 'Player 1' ? n1 : n2);
          setOppName(role === 'Player 1' ? n2 : n1);
        } else {
          const me = (localStorage.getItem('username') || 'You').slice(0, 16);
          setMyName(me || 'You');
          setOppName(role === 'Player 1' ? 'Player 2' : 'Player 1');
        }

        // Colors
        if (data.colors) {
          setColors({
            'Player 1': data.colors['Player 1'] || '#EF4444',
            'Player 2': data.colors['Player 2'] || '#3B82F6',
          });
          const myColor = data.colors[role] || (role === 'Player 1' ? '#EF4444' : '#3B82F6');
          if (role === 'Player 1') localStorage.setItem('cfColor', myColor);
          setSelectedColor(myColor);
        } else {
          const myColor = role === 'Player 1' ? '#EF4444' : '#3B82F6';
          setColors({ 'Player 1': '#EF4444', 'Player 2': '#3B82F6' });
          setSelectedColor(myColor);
          localStorage.setItem('cfColor', myColor);
        }

        // Avatars
        const av = data.avatars || { 'Player 1':'rocket', 'Player 2':'alien' };
        setMyAvatarId(av[role] || localStorage.getItem('cfAvatar') || 'rocket');
        setOppAvatarId(av[role === 'Player 1' ? 'Player 2' : 'Player 1'] || 'alien');

        // Stakes for the live game (if server includes)
        if (data.stakes) {
          setPairedInfo(prev => prev ? { ...prev, stakes: data.stakes } : { you: role === 'Player 2' ? 2 : 1, stakes: data.stakes });
        }

        const clean = makeBoard();
        setBoard(clean);
        prevBoardRef.current = cloneBoard(clean);
        setLastMove(null);
        setRematchVotes(0);
        setHasVotedRematch(false);
        setLobbyStatus('idle', { force: true });

        const yours = (data.currentPlayer || 'Player 1') === role;
        setTurnToast(yours ? "It's your turn!" : "It's your opponent's turn!");
        setTimeout(() => setTurnToast(null), 1100);
        return;
      }

      // Server can sync names/colors/avatars any time
      if (data.type === 'usernames' && data.usernames) {
        const role = playerRoleRef.current;
        const n1 = (data.usernames['Player 1'] || 'Player 1').slice(0, 16);
        const n2 = (data.usernames['Player 2'] || 'Player 2').slice(0, 16);
        setMyName(role === 'Player 1' ? n1 : n2);
        setOppName(role === 'Player 1' ? n2 : n1);
        return;
      }
      if (data.type === 'avatars' && data.avatars) {
        const role = playerRoleRef.current || (pairedInfo?.you === 2 ? 'Player 2' : 'Player 1');
        setMyAvatarId(data.avatars[role] || myAvatarId);
        setOppAvatarId(data.avatars[role === 'Player 1' ? 'Player 2' : 'Player 1'] || oppAvatarId);
        return;
      }

      // stakes update during matching
      if (data.type === 'stakes' && showMatch) {
        setPairedInfo(prev => prev ? { ...prev, stakes: data.stakes } : prev);
        return;
      }

      // Game update
      if (data.type === 'gameUpdate') {
        const nextBoard = data.board || makeBoard();
        const move = data.lastMove && typeof data.lastMove.row === 'number'
          ? data.lastMove
          : findNewMove(prevBoardRef.current, nextBoard);

        setBoard(nextBoard);
        prevBoardRef.current = cloneBoard(nextBoard);

        if (move) {
          setLastMove(move);
          if (!data.winner) {
            scheduleImpactSound();
          } else {
            if (playTimerRef.current) { clearTimeout(playTimerRef.current); playTimerRef.current = null; }
          }
        } else {
          setLastMove(null);
        }

        const prev = currentPlayerRef.current;
        const next = data.currentPlayer || 'Player 1';
        if (!data.winner && prev && next !== prev && playerRoleRef.current) {
          const yours = next === playerRoleRef.current;
          setTurnToast(yours ? "It's your turn!" : "It's your opponent's turn!");
          setTimeout(() => setTurnToast(null), 1100);
        }

        setCurrentPlayer(next);
        setWinner(data.winner || null);

        // One-time settlement when a winner lands
        if (data.winner && !settledOnceRef.current) {
          settledOnceRef.current = true;
          const myRole = playerRoleRef.current;
          const oppRole = myRole === 'Player 1' ? 'Player 2' : 'Player 1';
          const stakes = (pairedInfo && pairedInfo.stakes) || data.stakes || {};
          const myStake = Number(stakes?.[myRole]) || lockedStakeRef.current || Number(stakeSC) || 0;
          const oppStake = Number(stakes?.[oppRole]) || myStake; // fallback symmetrical

          if (data.winner === myRole) {
            // Pay: myStake (refund) + oppStake
            settleWin(myStake, oppStake);
            const nw = player1Wins + (myRole === 'Player 1' ? 1 : 0);
            const nw2 = player2Wins + (myRole === 'Player 2' ? 1 : 0);
            if (myRole === 'Player 1') { setPlayer1Wins(nw); localStorage.setItem('player1Wins', String(nw)); }
            else { setPlayer2Wins(nw2); localStorage.setItem('player2Wins', String(nw2)); }
          } else {
            // Loss: locked stake stays forfeited; zero out our local lock
            lockedStakeRef.current = 0;
            const nw = player1Wins + (data.winner === 'Player 1' ? 1 : 0);
            const nw2 = player2Wins + (data.winner === 'Player 2' ? 1 : 0);
            setPlayer1Wins(nw); localStorage.setItem('player1Wins', String(nw));
            setPlayer2Wins(nw2); localStorage.setItem('player2Wins', String(nw2));
            // Balance already reflected at lock time; winner’s client will credit themselves.
          }
        }
        return;
      }

      if (data.type === 'rematchUpdate') {
        const count = typeof data.count === 'number' ? data.count : rematchVotes;
        setRematchVotes(Math.max(0, Math.min(2, count)));
        return;
      }

      if (data.type === 'rematchStart') {
        gameActiveRef.current = true;
        settledOnceRef.current = false;
        const clean = makeBoard();
        setBoard(clean);
        prevBoardRef.current = cloneBoard(clean);
        setWinner(null);
        setCurrentPlayer('Player 1');
        setLastMove(null);
        setRematchVotes(0);
        setHasVotedRematch(false);
        setTurnToast("It's your turn!");
        setTimeout(() => setTurnToast(null), 1100);

        // lock for rematch if not already
        const desired = Math.max(0.01, Number(stakeSC) || 0);
        (async () => {
          if (lockedStakeRef.current <= 0) {
            await lockStake(desired);
          }
        })();
        return;
      }

      if (data.type === 'opponentLeft') {
        // If game didn’t finish with a winner, refund our stake
        if (!settledOnceRef.current) refundStake('opponent left (refund)');
        setShowMatch(false);
        setPairedInfo(null);
        setCountdown(null);
        gameActiveRef.current = false;
        setIsGameStarted(false);
        setWinner(null);
        setPlayerRole(null);
        setCurrentPlayer('Opponent left — back to lobby');
        const clean = makeBoard();
        setBoard(clean);
        prevBoardRef.current = cloneBoard(clean);
        setLastMove(null);
        setRematchVotes(0);
        setHasVotedRematch(false);
        setLobbyStatus('idle', { force: true });
        return;
      }

      if (data.type === 'end') {
        // No winner (or round canceled) → refund if still locked
        if (!settledOnceRef.current) refundStake('match end (refund)');
        setShowMatch(false);
        setPairedInfo(null);
        setCountdown(null);
        gameActiveRef.current = false;
        setIsGameStarted(false);
        setWinner(null);
        setPlayerRole(null);
        setCurrentPlayer('Back to lobby');
        const clean = makeBoard();
        setBoard(clean);
        prevBoardRef.current = cloneBoard(clean);
        setLastMove(null);
        setRematchVotes(0);
        setHasVotedRematch(false);
        setLobbyStatus('idle', { force: true });
        return;
      }
    };

    ws.onclose = () => {
      if (gameActiveRef.current || showMatch) {
        setCurrentPlayer('Reconnecting…');
        setTimeout(() => connectWSRef.current(true), 300);
      } else {
        setLobbyStatus('idle', { force: true });
        setCurrentPlayer('Disconnected — click Join to play');
      }
    };
  }, [player1Wins, player2Wins, rematchVotes, scheduleImpactSound, setLobbyStatus, showMatch, myAvatarId, oppAvatarId, pairedInfo, stakeSC, lockStake, refundStake, settleWin]);

  useEffect(() => {
    const backoff = { current: 300 };
    connectWSRef.current = (isRetry = false) => {
      const cur = wsRef.current;
      if (cur && (cur.readyState === WebSocket.OPEN || cur.readyState === WebSocket.CONNECTING)) return;
      const delay = isRetry ? Math.min(backoff.current, 5000) : 0;
      const doConnect = () => {
        const url = getWsUrl();
        console.log('[WS] connect:', url, '(retry:', isRetry, ')');
        const ws = new WebSocket(url);
        wsRef.current = ws;
        attachHandlers(ws);
        backoff.current = isRetry ? Math.min(backoff.current * 2, 5000) : 300;
      };
      if (delay) setTimeout(doConnect, delay); else doConnect();
    };
  }, [attachHandlers]);

  useEffect(() => {
    if (didInitRef.current) return;
    didInitRef.current = true;
    connectWSRef.current(false);
    return () => {
      if (playTimerRef.current) clearTimeout(playTimerRef.current);
      if (winTimerRef.current) clearTimeout(winTimerRef.current);
      cleanSocket();
    };
  }, [cleanSocket]);

  /* ========================= Actions ========================= */
  const withOpenSocket = (cb) => {
    const cur = wsRef.current;
    if (cur && cur.readyState === WebSocket.OPEN) { cb(cur); return; }
    if (cur && cur.readyState === WebSocket.CONNECTING) { setTimeout(() => withOpenSocket(cb), 120); return; }
    connectWSRef.current(true);
    setTimeout(() => withOpenSocket(cb), 180);
  };

  const handleCellClick = (_row, col) => {
    if (winner || !isGameStarted || playerRole !== currentPlayer) return;
    withOpenSocket((sock) => sock.send(JSON.stringify({ type: 'makeMove', col })));
  };

  const handleJoinGame = async () => {
    dropSound.prime();
    const name = (username || 'You').trim().slice(0, 16);
    const stake = Math.max(0.01, Number(stakeSC) || 0);
    localStorage.setItem('username', name);
    localStorage.setItem('cfColor', selectedColor);
    localStorage.setItem('cfAvatar', avatarId);
    localStorage.setItem('cfStake', String(stake));

    // Lock my stake up-front so balance reflects escrow
    const ok = await lockStake(stake);
    if (!ok) return;

    withOpenSocket((sock) => {
      try {
        sock.send(JSON.stringify({
          type:'joinGame',
          username: name,
          color: selectedColor,
          avatar: avatarId,
          stake
        }));
      } catch {}
      setLobbyStatus('queued');
      setShowMatch(true);
      setPairedInfo(null);
      setCountdown(null);
    });
  };

  const cancelMatchmaking = () => {
    setShowMatch(false);
    setPairedInfo(null);
    setCountdown(null);
    setLobbyStatus('idle', { force: true });
    setCurrentPlayer('Canceled — back to lobby');
    // refund if we locked already
    refundStake('canceled matchmaking');
    cleanSocket();
    setTimeout(() => connectWSRef.current(false), 150);
  };

  const handleResetGame = () => withOpenSocket(sock => sock.send(JSON.stringify({ type:'resetGame' })));

  const handleRematch = async () => {
    if (hasVotedRematch) return;
    setHasVotedRematch(true);
    setRematchVotes(v => Math.max(v, 1));

    const stake = Math.max(0.01, Number(stakeSC) || 0);
    // For rematch, (re)lock if needed
    if (lockedStakeRef.current <= 0) {
      const ok = await lockStake(stake);
      if (!ok) return;
    }

    withOpenSocket(sock => { try { sock.send(JSON.stringify({ type:'rematchVote', stake })); } catch {} });
  };

  const handleLeave = () => {
    withOpenSocket(sock => { try { sock.send(JSON.stringify({ type:'leaveGame' })); } catch {} });
    // If we leave before the game settles, refund our stake
    if (!settledOnceRef.current) refundStake('left game');
    setShowMatch(false);
    setPairedInfo(null);
    setCountdown(null);
    gameActiveRef.current = false;
    setIsGameStarted(false);
    setWinner(null);
    setPlayerRole(null);
    setRematchVotes(0);
    setHasVotedRematch(false);
    setCurrentPlayer('Left game — back to lobby');
    const clean = makeBoard();
    setBoard(clean);
    prevBoardRef.current = cloneBoard(clean);
    setLastMove(null);
    setLobbyStatus('idle', { force: true });
    cleanSocket();
    connectWSRef.current(false);
  };

  // polite leave on tab close → refund if needed
  useEffect(() => {
    const handler = async () => {
      try {
        const s = wsRef.current;
        if (s && s.readyState === WebSocket.OPEN) s.send(JSON.stringify({ type:'leaveGame' }));
      } catch {}
      if (!settledOnceRef.current) {
        try { await refundStake('page close'); } catch {}
      }
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [refundStake]);

  /* ========== Win/Lose sound (delayed, non-overlapping) ========== */
  const prevWinnerRef = useRef(null);
  useEffect(() => {
    if (winTimerRef.current) { clearTimeout(winTimerRef.current); winTimerRef.current = null; }
    if (!winner) { prevWinnerRef.current = null; return; }
    if (prevWinnerRef.current === winner) return;
    prevWinnerRef.current = winner;
    if (playTimerRef.current) { clearTimeout(playTimerRef.current); playTimerRef.current = null; }
    if (!mutedRef.current) {
      winTimerRef.current = setTimeout(() => {
        if (winner === playerRoleRef.current) winSound.play();
        else loseSound.play();
      }, WIN_SOUND_DELAY_MS);
    }
  }, [winner, winSound, loseSound, WIN_SOUND_DELAY_MS]);

  /* ========================= UI helpers ========================= */
  const isWinner = Boolean(winner && playerRole && winner === playerRole);
  const showOverlay = Boolean(winner && isGameStarted);
  const myRole = playerRole || '—';
  const myColor = colors[playerRole] || (playerRole === 'Player 2' ? '#3B82F6' : '#EF4444');
  const oppRole = playerRole === 'Player 1' ? 'Player 2' : 'Player 1';
  const oppColor = colors[oppRole] || '#3B82F6';

  const showNeutralLobby = !isGameStarted && (lobbyRef.current === 'idle' || lobbyRef.current === 'waiting');
  const showSearching    = !isGameStarted && (lobbyRef.current === 'queued' || lobbyRef.current === 'matching');

  const fmtSC = (n) => `${(Number(n) || 0).toFixed(2)} SC`;

  /* ========================= Render ========================= */
  return (
    <div className={`cf-page ${embedded ? 'cf-embed' : ''}`} onClick={primeAudio}>
      {/* Only render global NavBar if not embedded inside screen shell */}
      {!embedded && <NavBar />}

      {!embedded && <div className="nav-spacer" />}

      <div className="container py-2">
        <div className="row justify-content-center">
          <div className="col-12 col-md-11 col-lg-10">

            {/* Header (hidden when embedded via CSS) */}
            <div className="cf-hero">
              <div className="d-flex flex-column gap-2">
                <div className="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-2">
                  <div className="d-flex align-items-center gap-2">
                    <div className="badge-row">
                      <span className="badge-chip" title="Your identity">
                        <i className="bi bi-person-check" />
                        {isGameStarted ? `You're ${myRole}` :
                          (lobbyRef.current === 'queued' ? 'Queued…' :
                          lobbyRef.current === 'matching' ? 'Matching…' : 'Ready to play')}
                      </span>

                      {/* SC Balance */}
                      <span className="badge-chip" title="Stake Coin balance">
                        <i className="bi bi-wallet2" />
                        Balance: <strong className="ms-1">{fmtSC(scBalance)}</strong>
                      </span>

                      <span className="badge-chip" style={{ background: myColor, color: contrastText(myColor), fontWeight: 900 }}>
                        {myName || 'You'}
                      </span>

                      {/* avatar+name VS avatar+name */}
                      {isGameStarted && (
                        <div
                          className="vs-row"
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 8,
                            background: 'rgba(255,255,255,.18)',
                            padding: '.28rem .55rem',
                            borderRadius: 999,
                          }}
                        >
                          <Avatar id={myAvatarId} size={22} />
                          <span style={{ fontWeight: 900 }}>{myName || 'You'}</span>
                          <span style={{ opacity: .8, fontWeight: 900, marginInline: 6 }}>VS</span>
                          <Avatar id={oppAvatarId} size={22} />
                          <span style={{ fontWeight: 900 }}>{oppName || 'Opponent'}</span>
                        </div>
                      )}

                      <span className="badge-chip">
                        <i className="bi bi-hourglass-split" />
                        {winner ? `${winner} wins!` :
                          (isGameStarted ? `Turn: ${currentPlayer}` : 'Idle')}
                      </span>

                      {isGameStarted && (
                        <span className="badge-chip">
                          <i className="bi bi-palette-fill" />
                          {oppRole}: <span style={{
                            display:'inline-block', width:12, height:12, borderRadius:999,
                            background: oppColor, marginLeft:6, marginRight:2, border:'1px solid rgba(0,0,0,.25)'
                          }} />
                        </span>
                      )}
                    </div>

                    {/* sound toggle */}
                    <button
                      className="mute-btn ms-md-2"
                      onClick={(e) => { e.stopPropagation(); setMuted(prev => !prev); }}
                      title={muted ? 'Unmute' : 'Mute'}
                    >
                      <i className={`bi ${muted ? 'bi-volume-mute-fill' : 'bi-volume-up-fill'}`} />
                      <span style={{fontSize:'.8rem'}}>{muted ? 'Muted' : 'Sound'}</span>
                    </button>
                  </div>
                </div>

                {showSearching && !showMatch && (
                  <div className="lobby-strip" style={{justifyContent:'center'}}>
                    <div className="vs-dots" style={{display:'flex', gap:6, alignItems:'center'}}>
                      <div className="mm-dot" />
                      <div className="mm-dot" />
                      <div className="mm-dot" />
                    </div>
                    <span style={{opacity:.95, fontWeight:700}}>Looking for an opponent…</span>
                  </div>
                )}
              </div>
            </div>

            {/* Card with board */}
            <div className="card shadow-sm board-card-wrap">
              {/* Winner / Loser Overlay */}
              {showOverlay && (
                <div className="winlose-overlay">
                  <div className="winlose-card position-relative">
                    {isWinner && <div className="win-glow" aria-hidden="true" />}
                    <h2 className="winlose-title mb-2">
                      {isWinner ? (
                        <>
                          <i className="bi bi-trophy-fill text-success" />
                          You won!
                        </>
                      ) : (
                        <>
                          <i className="bi bi-emoji-frown-fill text-danger" />
                          You lost!
                        </>
                      )}
                    </h2>
                    <div className="winlose-actions">
                      <button className="btn btn-success btn-resp" onClick={handleRematch}>
                        <i className="bi bi-arrow-repeat me-1" /> Rematch ({rematchVotes}/2)
                      </button>
                      <button className="btn btn-outline-secondary btn-resp" onClick={handleLeave}>
                        <i className="bi bi-door-open me-1" /> Leave
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="card-body card-body-tight">
                <div className="row g-3 align-items-start justify-content-center">
                  {/* 3D Stage + Board */}
                  <div className="col-12 col-md-10">
                    <div className="board-outer">
                      <div className="board-wrap">
                        <div className="cf-stage">
                          <div className="board-frame">
                            <div className="board-skin position-relative">
                              <div className="board-glint"></div>

                              {/* Turn toast */}
                              {turnToast && <div className="turn-toast">{turnToast}</div>}

                              {isGameStarted ? (
                                <div className="board position-relative">
                                  {/* arrows */}
                                  {Array.from({ length: COLUMNS }).map((_, colIndex) => (
                                    <div key={`arrow-${colIndex}`}
                                         className="col-arrow"
                                         style={{ left: `calc(${(colIndex + 0.5) / COLUMNS * 100}% )` }}>
                                      <i className="bi bi-caret-down-fill"></i>
                                    </div>
                                  ))}

                                  {Array.from({ length: COLUMNS }).map((_, colIndex) => (
                                    <div key={colIndex} className="d-grid column-hover position-relative">
                                      {Array.from({ length: ROWS }).map((_, rowIndex) => {
                                        const cellVal = board[rowIndex][colIndex]; // 'Player 1' | 'Player 2' | null
                                        const isLast = lastMove && lastMove.row === rowIndex && lastMove.col === colIndex;
                                        const dropRows = isLast ? (rowIndex + 1) : 0;
                                        return (
                                          <div
                                            key={`${colIndex}-${rowIndex}`}
                                            className="cell"
                                            onClick={() => handleCellClick(rowIndex, colIndex)}
                                          >
                                            {cellVal && (
                                              <div
                                                className={`circle ${isLast ? 'token-drop' : ''}`}
                                                style={{
                                                  ...(tokenStyleFor(colors[cellVal])),
                                                  ...(isLast ? { '--drop-rows': dropRows } : {})
                                                }}
                                              />
                                            )}
                                          </div>
                                        );
                                      })}
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                /* ========== PRE-GAME HUD (type your stake) ========== */
                                (showNeutralLobby && (
                                  <div
                                    className="hud-on-board"
                                    onClick={(e) => e.stopPropagation()} // keep clicks off the board
                                  >
                                    <div className="prejoin-card">
                                      {/* Row 1 — header chip */}
                                      <div className="prejoin-row prejoin-head">
                                        <span className="chip">
                                          <i className="bi bi-controller"></i>
                                          Player Setup
                                        </span>
                                      </div>

                                      {/* Row 2 — Screen name + Color + Stake */}
                                      <div className="prejoin-row">
                                        {/* Screen name */}
                                        <div className="stack">
                                          <label className="stack-label">
                                            <i className="bi bi-pencil-square"></i>
                                            Screen name
                                          </label>
                                          <div className="input-group input-group-sm">
                                            <span className="input-group-text"><i className="bi bi-person" /></span>
                                            <input
                                              className="form-control"
                                              placeholder="Your screen name"
                                              maxLength={16}
                                              value={username}
                                              onChange={(e) => setUsername(e.target.value)}
                                            />
                                          </div>
                                        </div>

                                        {/* Color */}
                                        <div className="stack">
                                          <label className="stack-label">
                                            <i className="bi bi-palette-fill"></i>
                                            Color
                                          </label>
                                          <div className="swatch-wrap">
                                            {PALETTE.map((hex) => {
                                              const active = (selectedColor || '').toLowerCase() === hex.toLowerCase();
                                              return (
                                                <button
                                                  key={hex}
                                                  type="button"
                                                  onClick={() => setSelectedColor(hex)}
                                                  title={hex}
                                                  aria-label={`Choose ${hex}`}
                                                  className={`sw ${active ? 'is-active' : ''}`}
                                                  style={{ background: hex }}
                                                />
                                              );
                                            })}
                                          </div>
                                        </div>

                                        {/* Stake (SC) */}
                                        <div className="stack">
                                          <label className="stack-label">
                                            <i className="bi bi-coin"></i>
                                            Stake (SC)
                                          </label>
                                          <div className="input-group input-group-sm">
                                            <span className="input-group-text"><i className="bi bi-cash-stack" /></span>
                                            <input
                                              className="form-control"
                                              type="number"
                                              min="0.01"
                                              step="0.01"
                                              placeholder="e.g. 1.00"
                                              value={stakeSC}
                                              onChange={(e) => {
                                                const v = Math.max(0, Number(e.target.value) || 0);
                                                setStakeSC(v);
                                              }}
                                            />
                                          </div>
                                          <div className="form-text" style={{opacity:.85}}>
                                            Your balance: <strong>{fmtSC(scBalance)}</strong>. Both players stake; winner takes opponent’s stake.
                                          </div>
                                        </div>
                                      </div>

                                      {/* Row 3 — Avatar + Sound */}
                                      <div className="prejoin-row">
                                        {/* Bigger avatar preview + change */}
                                        <div className="stack">
                                          <label className="stack-label">
                                            <i className="bi bi-emoji-smile"></i>
                                            Avatar
                                          </label>
                                          <div className="d-flex align-items-center gap-2">
                                            <div className="avatar-xl">
                                              <Avatar id={avatarId} size={38} />
                                            </div>
                                            <button
                                              className="btn btn-outline-light btn-sm pill"
                                              onClick={(e) => { e.stopPropagation(); setShowAvatarModal(true); }}
                                              title="Choose avatar"
                                            >
                                              Change
                                            </button>
                                          </div>
                                        </div>

                                        {/* Sound toggle */}
                                        <div className="stack">
                                          <label className="stack-label">
                                            <i className="bi bi-volume-up-fill"></i>
                                            Sound
                                          </label>
                                          <div className="d-flex align-items-center gap-2">
                                            <button
                                              className="btn btn-outline-light btn-sm pill"
                                              onClick={(e) => { e.stopPropagation(); setMuted((m) => !m); }}
                                              title={muted ? 'Unmute' : 'Mute'}
                                            >
                                              <i className={`bi ${muted ? 'bi-volume-mute-fill' : 'bi-volume-up-fill'}`} />
                                              <span className="d-none d-sm-inline ms-1">{muted ? 'Muted' : 'On'}</span>
                                            </button>
                                          </div>
                                        </div>
                                      </div>

                                      {/* Row 4 — BIG Join */}
                                      <div className="prejoin-row prejoin-cta">
                                        <button
                                          className="btn btn-primary btn-lg pill cta-join pulse-loop"
                                          onClick={handleJoinGame}
                                          title="Join a game"
                                        >
                                          <i className="bi bi-play-fill"></i>
                                          <span className="fw-bold ms-1">Join Game</span>
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>

                            <div className="board-stand"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Wins */}
                  <div className="col-12">
                    <div className="wins-wrap">
                      <span className="badge text-bg-danger badge-resp">
                        <i className="bi bi-trophy-fill" /> P1 Wins: {player1Wins}
                      </span>
                      <span className="badge text-bg-primary badge-resp">
                        <i className="bi bi-trophy-fill" /> P2 Wins: {player2Wins}
                      </span>
                    </div>
                  </div>

                  {/* Controls */}
                  <div className="col-12">
                    <div className="d-flex flex-wrap gap-2 justify-content-center">
                      {isGameStarted && !winner && (
                        <button className="btn btn-warning btn-resp" onClick={() => { setTurnToast(null); handleResetGame(); }}>
                          <i className="bi bi-arrow-counterclockwise me-1" />
                          Reset Board
                        </button>
                      )}
                      {isGameStarted && winner && (
                        <button className="btn btn-success btn-resp" onClick={handleRematch}>
                          <i className="bi bi-arrow-repeat me-1" /> Rematch ({rematchVotes}/2)
                        </button>
                      )}
                      {isGameStarted && (
                        <button className="btn btn-outline-secondary btn-resp" onClick={handleLeave}>
                          <i className="bi bi-door-open me-1" /> Leave
                        </button>
                      )}
                      <button
                        className="btn btn-outline-danger btn-resp"
                        onClick={() => { setPlayer1Wins(0); setPlayer2Wins(0); localStorage.removeItem('player1Wins'); localStorage.removeItem('player2Wins'); }}
                      >
                        <i className="bi bi-x-circle me-1" />
                        Reset Win Count
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* ===== Matchmaking Modal ===== */}
      {showMatch && (
        <div className="match-overlay">
          <div className="match-card">
            <div className="match-header">
              <h3>Matchmaking</h3>
              <button className="mm-cancel" onClick={cancelMatchmaking}>Cancel</button>
            </div>

            <div className="match-body">
              {(() => {
                const youRole = pairedInfo?.you === 2 ? 'Player 2' : 'Player 1';
                const oppRole2  = youRole === 'Player 1' ? 'Player 2' : 'Player 1';

                const youName = pairedInfo?.usernames?.[youRole] ?? (username || 'You');
                const oppNameMM = pairedInfo?.usernames?.[oppRole2] ?? 'Searching…';

                const youColor = pairedInfo?.colors?.[youRole] ?? selectedColor;
                const oppColorMM = pairedInfo?.colors?.[oppRole2] ?? '#3B82F6';

                const youAvatar = pairedInfo?.avatars?.[youRole] ?? avatarId;
                const oppAvatar = pairedInfo?.avatars?.[oppRole2] ?? null; // null => show dots

                const youStake = pairedInfo?.stakes?.[youRole];
                const oppStake = pairedInfo?.stakes?.[oppRole2];

                const fmtStakeMM = (v) =>
                  (typeof v === 'number' ? v.toFixed(2) + ' SC' : (v || '—'));

                return (
                  <>
                    {/* You */}
                    <div className="match-col">
                      <div className="mm-avatar" title="Your avatar">
                        {findAvatar(youAvatar).glyph}
                      </div>
                      <div className="mm-pill">
                        <i className="bi bi-person-badge" />
                        {youName}
                      </div>
                      <div className="mm-pill">
                        <i className="bi bi-palette-fill" />
                        Color <span className="mm-swab" style={{ background: youColor, marginLeft: 6 }} />
                      </div>
                      <div className="mm-pill">
                        <i className="bi bi-coin" />
                        Your bet: <strong className="ms-1">{fmtStakeMM(((youStake ?? Number(stakeSC)) || 0))}</strong>
                      </div>
                    </div>

                    <div className="match-divider">VS</div>

                    {/* Opponent (or searching) */}
                    <div className="match-col">
                      <div className="mm-avatar" title="Opponent avatar">
                        {oppAvatar ? findAvatar(oppAvatar).glyph : (
                          <div className="mm-dots">
                            <div className="mm-dot" />
                            <div className="mm-dot" />
                            <div className="mm-dot" />
                          </div>
                        )}
                      </div>
                      <div className="mm-pill">
                        <i className="bi bi-person-badge" />
                        {oppAvatar ? oppNameMM : 'Searching…'}
                      </div>
                      <div className="mm-pill">
                        <i className="bi bi-palette-fill" />
                        Color <span className="mm-swab" style={{ background: oppColorMM, marginLeft: 6 }} />
                      </div>
                      <div className="mm-pill">
                        <i className="bi bi-coin" />
                        Opponent bet: <strong className="ms-1">{fmtStakeMM(oppStake)}</strong>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>

            <div className="mm-footer">
              {typeof countdown === 'number'
                ? <div className="mm-pill">Game starts in <strong style={{marginLeft:4}}>{countdown}</strong>…</div>
                : <div className="mm-pill">Waiting for opponent…</div>}
            </div>
          </div>
        </div>
      )}

      {/* ===== Avatar Picker Modal ===== */}
      {showAvatarModal && (
        <div className="avatar-modal" onClick={() => setShowAvatarModal(false)}>
          <div className="avatar-card" onClick={e => e.stopPropagation()}>
            <div className="avatar-hd">
              <strong>Choose your avatar</strong>
              <button className="mm-cancel" onClick={() => setShowAvatarModal(false)}>Close</button>
            </div>

            <div className="avatar-grid">
              {AVATAR_SET.map(a => (
                <button
                  key={a.id}
                  className="avatar-btn"
                  onClick={() => {
                    setAvatarId(a.id);
                    setMyAvatarId(a.id);
                    localStorage.setItem('cfAvatar', a.id);
                    setShowAvatarModal(false);
                  }}
                  title={a.label}
                >
                  <div className="avatar-hero">{a.glyph}</div>
                  <div className="avatar-name">{a.label}</div>
                </button>
              ))}
            </div>

            <div className="avatar-ft">
              <button className="mm-cancel" onClick={() => setShowAvatarModal(false)}>Done</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
