/* eslint-disable react/jsx-pascal-case */
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Navbar, Nav, Container, Button, NavDropdown, Spinner } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import "./NavBar.css";

/* ===== API helpers (same pattern as your games) ===== */
const API = "http://localhost:3002";

function authFetch(path, options = {}) {
  const token = localStorage.getItem("token") || "";
  return fetch(`${API}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });
}

async function getBalance() {
  try {
    const r = await authFetch("/balance");
    const j = await r.json().catch(() => ({}));
    const n = Number(j?.sc_balance);
    return Number.isFinite(n) ? n : 0;
  } catch {
    return 0;
  }
}

export default function NavBar() {
  /* ===== Auth state ===== */
  const readAuth = () => {
    const token = localStorage.getItem("token") || "";
    const username = localStorage.getItem("username") || "";
    return { isUserLoggedIn: Boolean(token && username), username };
  };
  const [{ isUserLoggedIn, username }, setAuth] = useState(readAuth);

  /* ===== Wallet balance ===== */
  const [balance, setBalance] = useState(null); // null = unknown/loading
  const [loadingBal, setLoadingBal] = useState(false);

  const fmtSC = useMemo(
    () => (n) => `${(Number(n) || 0).toFixed(2)} SC`,
    []
  );

  const refreshBalance = async () => {
    if (!isUserLoggedIn) return;
    try {
      setLoadingBal(true);
      const n = await getBalance();
      setBalance(n);
    } finally {
      setLoadingBal(false);
    }
  };

  /* Keep nav height in a CSS var for pages (e.g., --nav-h) */
  const navRef = useRef(null);
  useEffect(() => {
    const applyH = () => {
      const h = navRef.current?.offsetHeight || 64;
      document.documentElement.style.setProperty("--nav-h", `${h}px`);
    };
    applyH();
    const ro = new ResizeObserver(applyH);
    if (navRef.current) ro.observe(navRef.current);
    window.addEventListener("resize", applyH);
    return () => {
      window.removeEventListener("resize", applyH);
      ro.disconnect();
    };
  }, []);

  /* Sync auth across tabs + app */
  useEffect(() => {
    const sync = () => setAuth(readAuth());
    window.addEventListener("authchange", sync);
    window.addEventListener("storage", sync);
    // initial
    sync();
    return () => {
      window.removeEventListener("authchange", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  /* Load/refresh balance when logged in */
  useEffect(() => {
    if (!isUserLoggedIn) { setBalance(null); return; }
    let timer = null;

    const doRefresh = () => { refreshBalance(); };
    doRefresh();

    // refresh every 30s while logged in
    timer = setInterval(doRefresh, 30000);

    // refresh when window/tab gains focus
    const onFocus = () => doRefresh();
    const onVisible = () => { if (document.visibilityState === "visible") doRefresh(); };

    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onVisible);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isUserLoggedIn]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    // If you also store wallet keys and want hard logout, uncomment:
    // localStorage.removeItem("roc_public");
    // localStorage.removeItem("roc_secret");

    window.dispatchEvent(new Event("authchange"));
    setAuth(readAuth());
  };

  return (
    <Navbar ref={navRef} className="app-navbar shadow-sm" bg="dark" variant="dark" fixed="top" expand="md">
      <Container fluid>
        {/* Brand */}
        <Navbar.Brand href="/" className="brand">
          <span className="brand-emblem">🎲</span>
          <span className="brand-name">Gambit</span>
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="main-nav">
          <i className="bi bi-list" />
        </Navbar.Toggle>

        <Navbar.Collapse id="main-nav">
          {/* Left nav links */}
          <Nav className="me-auto">
            <Nav.Link href="/">Roll of Cards</Nav.Link>
            <Nav.Link href="/Game2">In-Between</Nav.Link>
            <Nav.Link href="/connect-four">Connect Four</Nav.Link>
            <Nav.Link href="/war">War</Nav.Link>
          </Nav>

          {/* Right side: wallet + auth */}
          <div className="d-flex align-items-center gap-2">
            {/* Wallet pill */}
            {isUserLoggedIn && (
              <Button
                variant="outline-light"
                className="wallet-pill"
                onClick={refreshBalance}
                title="Tap to refresh balance"
              >
                <i className="bi bi-wallet2 me-2" />
                {loadingBal ? (
                  <span className="d-inline-flex align-items-center">
                    <Spinner animation="border" size="sm" className="me-2" />
                    Loading…
                  </span>
                ) : (
                  <strong>{balance === null ? "—" : fmtSC(balance)}</strong>
                )}
              </Button>
            )}

            {/* Auth area */}
            {isUserLoggedIn ? (
              <NavDropdown
                align="end"
                title={
                  <span className="user-pill">
                    <i className="bi bi-person-circle me-2" />
                    {username}
                  </span>
                }
                id="user-dd"
              >
                <NavDropdown.Item href="/profile">
                  <i className="bi bi-person-gear me-2" />
                  Profile
                </NavDropdown.Item>
                <NavDropdown.Item href="/wallet">
                  <i className="bi bi-cash-coin me-2" />
                  Wallet
                </NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item onClick={handleLogout}>
                  <i className="bi bi-box-arrow-right me-2" />
                  Logout
                </NavDropdown.Item>
              </NavDropdown>
            ) : (
              <Button as="a" href="/registration" className="login-btn">
                <i className="bi bi-box-arrow-in-right me-2" />
                Login / Register
              </Button>
            )}
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
