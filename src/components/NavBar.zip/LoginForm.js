// src/components/auth/LoginForm.js
import React, { useState } from "react";

const API = process.env.REACT_APP_API_BASE || "http://localhost:3002";
const HORIZON = "https://horizon-testnet.stellar.org";

// Keys your Game.js already uses:
const LS_BAL    = "roc_last_balance"; // cached balance
const LS_PUBLIC = "roc_public";       // cached wallet pubkey

async function fetchStellarBalance(pubkey) {
  try {
    const res = await fetch(`${HORIZON}/accounts/${encodeURIComponent(pubkey)}`);
    if (!res.ok) return null;
    const account = await res.json();
    const native = (account.balances || []).find((b) => b.asset_type === "native");
    return native ? parseFloat(native.balance) : 0;
  } catch {
    return null;
  }
}

export default function LoginForm() {
  const [formData, setFormData] = useState({ username: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((s) => ({ ...s, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      // 1) login
      const res = await fetch(`${API}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Login failed");

      // 2) save auth
      localStorage.setItem("token", data.token);
      localStorage.setItem("username", data.username);

      // 3) load profile for wallet pubkey
      let walletPublic = null;
      try {
        const r2 = await fetch(`${API}/me`, {
          headers: { Authorization: `Bearer ${data.token}` },
        });
        if (r2.ok) {
          const me = await r2.json();
          if (me.wallet_public) walletPublic = me.wallet_public;
        }
      } catch {}

      // 4) preload live XLM balance if pubkey exists
      if (walletPublic) {
        localStorage.setItem(LS_PUBLIC, walletPublic);
        const lumens = await fetchStellarBalance(walletPublic);
        if (lumens != null) localStorage.setItem(LS_BAL, String(lumens));
      }

      // 5) redirect home
      window.location.replace("/");
    } catch (e2) {
      setErr(e2.message || "Failed to sign in");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ maxWidth: 360 }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-2">
          <label>Username:</label>
          <input
            className="form-control"
            name="username"
            value={formData.username}
            onChange={handleChange}
            autoComplete="username"
            required
          />
        </div>
        <div className="mb-3">
          <label>Password:</label>
          <input
            className="form-control"
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            autoComplete="current-password"
            required
          />
        </div>
        {err && <div className="alert alert-danger py-2">{err}</div>}
        <button className="btn btn-primary w-100" type="submit" disabled={busy}>
          {busy ? "Signing in…" : "Login"}
        </button>
      </form>
    </div>
  );
}
