// src/components/auth/Registration.js
import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Container from "react-bootstrap/Container";
import NavBar from "./NavBar";

const API = process.env.REACT_APP_API_BASE || "http://localhost:3002";

function Registration({ onAuthed }) {
  const [formData, setFormData] = useState({ email: "", username: "", password: "" });
  const [registrationError, setRegistrationError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [isRegistering, setIsRegistering] = useState(true);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((s) => ({ ...s, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setRegistrationError(null);
    setBusy(true);

    try {
      const url = `${API}${isRegistering ? "/registration" : "/login"}`;
      const payload = isRegistering
        ? { email: formData.email, username: formData.username, password: formData.password }
        : { username: formData.username, password: formData.password };

      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.message || `HTTP ${res.status}`);

      localStorage.setItem("token", data.token);
      localStorage.setItem("username", data.username);

      if (onAuthed) onAuthed({ username: data.username, token: data.token });

      // go home
      window.location.replace("/");

      // clear PW field only
      setFormData((s) => ({ ...s, password: "" }));
    } catch (err) {
      setRegistrationError(err.message || "An error occurred. Please try again later.");
    } finally {
      setBusy(false);
    }
  };

  const toggleForm = () => {
    setIsRegistering((v) => !v);
    setRegistrationError(null);
  };

  return (
    <Container>
      <NavBar />
      <Form
        onSubmit={handleSubmit}
        className="mt-5"
        style={{ backgroundColor: "#C7E7FF", padding: 20, borderRadius: 10, maxWidth: 520 }}
      >
        <h2 className="mb-4">
          {isRegistering ? "Register" : "Login"}{" "}
          <small>
            <Button
              variant="link"
              onClick={toggleForm}
              className="p-0 m-0"
              style={{ fontSize: "1rem" }}
            >
              {isRegistering ? "Already have an account?" : "Don't have an account?"}
            </Button>
          </small>
        </h2>

        {registrationError && (
          <div className="alert alert-danger" role="alert">
            {registrationError}
          </div>
        )}

        {isRegistering && (
          <Form.Group controlId="formEmail" className="mb-3">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              autoComplete="email"
              required
            />
            <Form.Text className="text-muted">We’ll never share your email.</Form.Text>
          </Form.Group>
        )}

        <Form.Group controlId="formUserName" className="mb-3">
          <Form.Label>User Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            autoComplete="username"
            required
          />
        </Form.Group>

        <Form.Group controlId="formPassword" className="mb-3">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            autoComplete={isRegistering ? "new-password" : "current-password"}
            required
          />
        </Form.Group>

        {isRegistering && (
          <Form.Group controlId="formBasicCheckbox" className="mb-3">
            <Form.Check type="checkbox" label="I agree to the terms and conditions" required />
          </Form.Group>
        )}

        <Button variant="success" type="submit" disabled={busy}>
          {busy ? (isRegistering ? "Creating…" : "Signing in…") : isRegistering ? "Register" : "Login"}
        </Button>
      </Form>
    </Container>
  );
}

export default Registration;
